﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaPresentacion; 

namespace CapaNegocio
{
    public class ProductBusinnes
    {
        ProductData data = new ProductData();
        ProductEntities entities = new ProductEntities();

        public DataTable ListingProducts() 
        {
            return data.ListarProducts(); 
        }

        public DataTable SearchingProducts(string Search) 
        {
            entities.Search = Search;
            return data.SearchProducts(entities); 
        }  

        public void CreatingProducts(ProductEntities product) 
        {
            data.CreateProduct(product); 
        }

        public void UpdatingProducts(ProductEntities product) 
        {
            data.UpdateProduct(product); 
        }

        public void BorrarProduct(int id) 
        {
            data.DeleteProduct(id); 
        }
    }
}
