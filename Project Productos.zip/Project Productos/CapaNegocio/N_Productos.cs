﻿using CapaDatos;
using CapaPresentacion;
using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidades;

namespace CapaNegocio
{
    public class N_Productos
    {
        D_Productos ObjD = new D_Productos();

        public DataTable ListandoProductos() 
        {
            return ObjD.ListarProductos(); 
        }

        public void CreatingProducts(E_Productos product)
        {
            ObjD.CreateProduct(product);
        }
        public void UpdatingProducts(E_Productos product)
        {
            ObjD.UpdateProduct(product);
        }

        public void DeletingProducts(int id)
        {
            ObjD.BorrarProduct(id); 
        }

        public void SummaringTotals(E_Productos product) 
        {
            ObjD.MostrarTotal(product); 
        }
    }
}
