﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class E_Categoria
    {
        private int _idcategoria;
        private string _Codigocategoria;
        private string _Nombrecategoria;
        private string _Descripcioncategoria;

        public int Idcategoria { get => _idcategoria; set => _idcategoria = value; }
        public string Codigocategoria { get => _Codigocategoria; set => _Codigocategoria = value; }
        public string Nombrecategoria { get => _Nombrecategoria; set => _Nombrecategoria = value; }
        public string Descripcioncategoria { get => _Descripcioncategoria; set => _Descripcioncategoria = value; }
    }
}
