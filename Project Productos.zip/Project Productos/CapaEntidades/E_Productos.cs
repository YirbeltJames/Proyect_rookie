﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class E_Productos
    {
        private int _Idproductos;
        private string _Codigoproducto;
        private string _Producto;
        private int _Idcategoria;
        private int _Idmarca;
        private decimal _Preciocompra;
        private decimal _Precioventa;
        private int _stock;

        private string totalCategoria;
        private string totalMarca;
        private string totalProductos;
        private string totalStock; 

        public int Idproductos { get => _Idproductos; set => _Idproductos = value; }
        public string Codigoproducto { get => _Codigoproducto; set => _Codigoproducto = value; }
        public string Producto { get => _Producto; set => _Producto = value; }
        public int Idcategoria { get => _Idcategoria; set => _Idcategoria = value; }
        public int Idmarca { get => _Idmarca; set => _Idmarca = value; }
        public decimal Precio_compra { get => _Preciocompra; set => _Preciocompra = value; }
        public decimal Precio_venta { get => _Precioventa; set => _Precioventa = value; }
        public int Stock { get => _stock; set => _stock = value; }
        public string TotalCategoria { get => totalCategoria; set => totalCategoria = value; }
        public string TotalMarca { get => totalMarca; set => totalMarca = value; }
        public string TotalProductos { get => totalProductos; set => totalProductos = value; }
        public string TotalStock { get => totalStock; set => totalStock = value; }
    }
}
