﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaPresentacion
{
    public class ProductEntities
    {
        private int _id;
        private string _Code;
        private string _Product;
        private decimal _Price_buy;
        private decimal _Price_sale;
        private int _Stock;
        private int _Idcategory;
        private int _Idbrand;
        private string search;

        public int Id { get => _id; set => _id = value; }
        public string Code { get => _Code; set => _Code = value; }
        public string Product { get => _Product; set => _Product = value; }
        public decimal Price_buy { get => _Price_buy; set => _Price_buy = value; }
        public decimal Price_sale { get => _Price_sale; set => _Price_sale = value; }
        public int Stock { get => _Stock; set => _Stock = value; }
        public int Idcategory { get => _Idcategory; set => _Idcategory = value; }
        public int Idbrand { get => _Idbrand; set => _Idbrand = value; }
        public string Search { get => search; set => search = value; }
    }
}
