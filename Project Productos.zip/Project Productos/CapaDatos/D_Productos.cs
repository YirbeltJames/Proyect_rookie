﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidades;
using CapaPresentacion;

namespace CapaDatos
{
    public class D_Productos
    {
        SqlConnection conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["conectar"].ConnectionString);

        public DataTable ListarProductos()
        {
            DataTable tabla = new DataTable();
            SqlDataReader LeerFilas;
            SqlCommand cmd = new SqlCommand("SP_LISTARPRODUCTOS", conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            LeerFilas = cmd.ExecuteReader();
            tabla.Load(LeerFilas);

            LeerFilas.Close();
            conexion.Close();

            return tabla; 
        }

        public DataTable BuscarProducts(ProductEntities product)
        {
            DataTable tabla = new DataTable();
            SqlCommand cmd = new SqlCommand("SP_BUSCARPRODUCTOS", conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            cmd.Parameters.AddWithValue("@BUSCAR", product.Search);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(tabla);

            conexion.Close();
            return tabla;
        }

        public void BorrarProduct(int id)
        {
            SqlCommand cmd = new SqlCommand("SP_DELETEPRODUCTS", conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            cmd.Parameters.AddWithValue("@ID", id);

            cmd.ExecuteNonQuery();
            conexion.Close();
        }

        public void CreateProduct(E_Productos product)
        {
            SqlCommand cmd = new SqlCommand("SP_INGRESARPRODUCTO", conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            cmd.Parameters.AddWithValue("@PRODUCT", product.Producto);
            cmd.Parameters.AddWithValue("@PRICE_BUY", product.Precio_venta);
            cmd.Parameters.AddWithValue("@STOCK", product.Stock);
            cmd.Parameters.AddWithValue("@IDCATEGORY", product.Idcategoria);
            cmd.Parameters.AddWithValue("@IDBRAND", product.Idmarca);

            cmd.ExecuteNonQuery();
            conexion.Close();
        }

        public void UpdateProduct(E_Productos product)
        {
            SqlCommand cmd = new SqlCommand("SP_UPDATEPRODUCTS", conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            cmd.Parameters.AddWithValue("@ID", product.Idcategoria);
            cmd.Parameters.AddWithValue("@PRODUCT", product.Producto);
            cmd.Parameters.AddWithValue("@PRICE_BUY", product.Precio_compra);
            cmd.Parameters.AddWithValue("@PRICE_SALE", product.Precio_venta);
            cmd.Parameters.AddWithValue("@STOCK", product.Stock);
            cmd.Parameters.AddWithValue("@IDCATEGORY", product.Idcategoria);
            cmd.Parameters.AddWithValue("@IDBRAND", product.Idmarca);

        }

        public void MostrarTotal(E_Productos products) 
        {
            SqlCommand cmd = new SqlCommand("SUMMARYPRODUCTS", conexion);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter TotalCategoria = new SqlParameter("@TOTALCATEGORIA", 0);
            TotalCategoria.Direction = ParameterDirection.Output;

            SqlParameter TotalMarca = new SqlParameter("@TOTALMARCA", 0);
            TotalMarca.Direction = ParameterDirection.Output;

            SqlParameter TotalProductos = new SqlParameter("@TOTALPRODUCTO", 0);
            TotalProductos.Direction = ParameterDirection.Output;

            SqlParameter TotalStock = new SqlParameter("@SUMSTOCK", 0);
            TotalStock.Direction = ParameterDirection.Output;

            cmd.Parameters.Add(TotalCategoria);
            cmd.Parameters.Add(TotalMarca);
            cmd.Parameters.Add(TotalProductos);
            cmd.Parameters.Add(TotalStock);
            conexion.Open();

            cmd.ExecuteNonQuery();

            products.TotalCategoria = cmd.Parameters["@TOTALCATEGORIA"].Value.ToString();
            products.TotalMarca = cmd.Parameters["@TOTALMarca"].Value.ToString();
            products.TotalProductos = cmd.Parameters["@TOTALPRODUCTO"].Value.ToString();
            products.TotalStock = cmd.Parameters["@SUMSTOCK"].Value.ToString();

            conexion.Close(); 
        } 

    }
}
