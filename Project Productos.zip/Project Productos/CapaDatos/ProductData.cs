﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidades;
using CapaPresentacion; 

namespace CapaDatos
{
    public class ProductData
    {
        SqlConnection conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["conectar"].ConnectionString);

        public DataTable ListarProducts()
        {
            DataTable tabla = new DataTable();
            SqlDataReader ReadRows;
            SqlCommand cmd = new SqlCommand("SP_LISTARPRODUCTOS", conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            ReadRows = cmd.ExecuteReader();
            tabla.Load(ReadRows);

            ReadRows.Close();
            conexion.Close();

            return tabla;
        }

        public DataTable SearchProducts(ProductEntities product) 
        {
            DataTable tabla = new DataTable();
            SqlCommand cmd = new SqlCommand("SP_BUSCARPRODUCTOS", conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            cmd.Parameters.AddWithValue("@BUSCAR", product.Search);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(tabla);

            conexion.Close();
            return tabla; 
        }

       public void DeleteProduct(int id) 
       {
         SqlCommand cmd = new SqlCommand("SP_DELETEPRODUCTS", conexion); 
         cmd.CommandType = CommandType.StoredProcedure;
         conexion.Open();

         cmd.Parameters.AddWithValue("@ID", id);

         cmd.ExecuteNonQuery();
         conexion.Close(); 
        }

        public void CreateProduct(ProductEntities product) 
        {
            SqlCommand cmd = new SqlCommand("SP_CREATEPRODUCTS", conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            cmd.Parameters.AddWithValue("@product", product.Product);
            cmd.Parameters.AddWithValue("@product", product.Price_buy);
            cmd.Parameters.AddWithValue("@product", product.Price_sale);
            cmd.Parameters.AddWithValue("@product", product.Stock);
            cmd.Parameters.AddWithValue("@product", product.Idcategory);
            cmd.Parameters.AddWithValue("@product", product.Idbrand);

            cmd.ExecuteNonQuery();
            conexion.Close(); 
        }

        public void UpdateProduct(ProductEntities product) 
        {
          SqlCommand cmd = new SqlCommand("SP_UPDATEPRODUCTS", conexion);
          cmd.CommandType = CommandType.StoredProcedure;
          conexion.Open();

            cmd.Parameters.AddWithValue("@id", product.Id);
            cmd.Parameters.AddWithValue("@product", product.Product);
            cmd.Parameters.AddWithValue("@price_buy", product.Price_buy);
            cmd.Parameters.AddWithValue("@price_sale", product.Price_sale);
            cmd.Parameters.AddWithValue("@stock", product.Idcategory);
            cmd.Parameters.AddWithValue("@idcategory", product.Idbrand);
            cmd.Parameters.AddWithValue("idbrand", product.Idbrand); 

        }
    }
}
