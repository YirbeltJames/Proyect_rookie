﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        public void PantallaOK() 
        {
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location; 

        }

        private void Wrapper_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            PantallaOK(); 
        }

        private void Salir_Click(object sender, EventArgs e)
        {
            DialogResult resultado = new DialogResult();
            Form Mensaje = new FrmInformation("¿SEGURO DESEA SALIR DEL SISTEMA?");
            resultado = Mensaje.ShowDialog();

            if (resultado == DialogResult.OK) 
            {
                Application.Exit(); 
            }
        }

        private void lineShape1_Click(object sender, EventArgs e)
        {

        }

        public void SeleccionandoBotones(Bunifu.Framework.UI.BunifuFlatButton sender) 
        {
            BtnDashboard.Textcolor = Color.White;
            BtnProductos.Textcolor = Color.White;
            BtnVentas.Textcolor = Color.White;
            BtnCompras.Textcolor = Color.White;
            BtnTrabajadores.Textcolor = Color.White;
            BtnClientes.Textcolor = Color.White;
            BtnProveedores.Textcolor = Color.White;
            BtnGanancias.Textcolor = Color.White;

            sender.selected = true;

            if (sender.selected) 
            {
                sender.Textcolor = Color.FromArgb(98, 195, 140); 
            }
        }

        private void SeguirBoton(Bunifu.Framework.UI.BunifuFlatButton sender) 
        {
            Flecha.Top = sender.Top; 
        }


        private void BtnDashboard_Click(object sender, EventArgs e)
        {
            SeleccionandoBotones((Bunifu.Framework.UI.BunifuFlatButton)sender);
            SeguirBoton((Bunifu.Framework.UI.BunifuFlatButton)sender);
            AbrirFormularioEnWrapper(new FrmDashboard());
        }

        private void BtnProveedores_Click(object sender, EventArgs e)
        {
            SeleccionandoBotones((Bunifu.Framework.UI.BunifuFlatButton)sender);
            SeguirBoton((Bunifu.Framework.UI.BunifuFlatButton)sender); 
        }

        private void BtnClientes_Click(object sender, EventArgs e)
        {
            SeleccionandoBotones((Bunifu.Framework.UI.BunifuFlatButton)sender);
            SeguirBoton((Bunifu.Framework.UI.BunifuFlatButton)sender);
        }

        private void BtnTrabajadores_Click(object sender, EventArgs e)
        {
            SeleccionandoBotones((Bunifu.Framework.UI.BunifuFlatButton)sender);
            SeguirBoton((Bunifu.Framework.UI.BunifuFlatButton)sender);
        }

        private void BtnCompras_Click(object sender, EventArgs e)
        {
            SeleccionandoBotones((Bunifu.Framework.UI.BunifuFlatButton)sender);
            SeguirBoton((Bunifu.Framework.UI.BunifuFlatButton)sender);
        }

        private void BtnVentas_Click(object sender, EventArgs e)
        {
            SeleccionandoBotones((Bunifu.Framework.UI.BunifuFlatButton)sender);
            SeguirBoton((Bunifu.Framework.UI.BunifuFlatButton)sender);
        }

        private void BtnProductos_Click(object sender, EventArgs e)
        {
            SeleccionandoBotones((Bunifu.Framework.UI.BunifuFlatButton)sender);
            SeguirBoton((Bunifu.Framework.UI.BunifuFlatButton)sender);
            AbrirFormularioEnWrapper(new FrmProductos()); 
        }

        private void BtnGanancias_Click(object sender, EventArgs e)
        {
            SeleccionandoBotones((Bunifu.Framework.UI.BunifuFlatButton)sender);
            SeguirBoton((Bunifu.Framework.UI.BunifuFlatButton)sender);
        }

        private void Sidebar_Paint(object sender, PaintEventArgs e)
        {

        }

        private Form FormActivado = null;

        private void AbrirFormularioEnWrapper(Form FormHijo) 
        {
            if (FormActivado != null) FormActivado.Close();
            FormActivado = FormHijo;
            FormHijo.TopLevel = false;
            FormHijo.Dock = DockStyle.Fill;
            Wrapper.Controls.Add(FormHijo);
            Wrapper.Tag = FormHijo;
            FormHijo.BringToFront();
            FormHijo.Show(); 
        }
    }
}
