﻿using CapaEntidades;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FrmMarca : Form
    {
        private string idMarca;
        private bool Editarse = false;

        E_Marca objEntidad = new E_Marca();
        N_Marca objNegocio = new N_Marca();

        public FrmMarca()
        {
            InitializeComponent();
        }

        private void TablaCategoria_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Close(); 
        }

        private void FrmMarca_Load(object sender, EventArgs e)
        {
            mostrarBuscarTabla("");
            accionesTablas();
        }

        public void mostrarBuscarTabla(string buscar)
        {
            N_Marca ObjNegocio = new N_Marca();
            TablaMarca.DataSource = ObjNegocio.ListandoMarca(buscar);
        }

        public void accionesTablas()
        {
            TablaMarca.Columns[0].Visible = false;
            TablaMarca.Columns[1].Width = 60;
            TablaMarca.Columns[2].Width = 170;

            TablaMarca.ClearSelection();
        }

        private void txtbuscar_TextChanged(object sender, EventArgs e)
        {
            mostrarBuscarTabla(txtbuscar.Text);
        }

        private void LimpiarCajas()
        {
            txtCodigo.Text = "";
            txtNombre.Text = "";
            txtDescripcion.Text = "";
            txtNombre.Focus();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCajas();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (TablaMarca.SelectedRows.Count > 0)
            {
                Editarse = true;
                idMarca = TablaMarca.CurrentRow.Cells[0].Value.ToString();
                txtCodigo.Text = TablaMarca.CurrentRow.Cells[1].Value.ToString();
                txtNombre.Text = TablaMarca.CurrentRow.Cells[2].Value.ToString();
                txtDescripcion.Text = TablaMarca.CurrentRow.Cells[3].Value.ToString();
            }
            else
            {
                MessageBox.Show("Selecciona la fila que desea Editar");
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (Editarse == false)
            {
                try
                {
                    objEntidad.NombreMarca = txtNombre.Text.ToUpper();
                    objEntidad.DescripcionMarca = txtDescripcion.Text.ToUpper();

                    objNegocio.InsertarMarca(objEntidad);

                    FrmSuccess.Confirmacionform("GUARDADO");
                    mostrarBuscarTabla("");
                    LimpiarCajas();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("No se pudo guardar correctamente" + Ex);
                }
            }

            if (Editarse == true)
            {
                try
                {
                    objEntidad.IdMarca = Convert.ToInt32(idMarca);
                    objEntidad.NombreMarca = txtNombre.Text.ToUpper();
                    objEntidad.DescripcionMarca = txtDescripcion.Text.ToUpper();

                    objNegocio.EditandoMarca(objEntidad);

                    FrmSuccess.Confirmacionform("EDITADO");
                    mostrarBuscarTabla("");
                    LimpiarCajas();
                    Editarse = false;
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("No se pudo Editar correctamente" + Ex);
                }
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult resultado = new DialogResult();
                FrmInformation frm = new FrmInformation("¿ESTAS SEGURO DE ELIMINAR EL REGISTRO?");
                resultado = frm.ShowDialog();

                if (resultado == DialogResult.OK)
                {
                    objEntidad.IdMarca = Convert.ToInt32(TablaMarca.CurrentRow.Cells[0].Value.ToString());
                    objNegocio.EliminandoMarca(objEntidad);

                    FrmSuccess.Confirmacionform("ELIMINADO");
                    mostrarBuscarTabla("");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Seleccione la fila que desea eliminar" + Ex);
            }

        }
    }
}
