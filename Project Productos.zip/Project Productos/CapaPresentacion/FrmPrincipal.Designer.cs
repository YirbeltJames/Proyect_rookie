﻿namespace CapaPresentacion
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrincipal));
            this.Sidebar = new System.Windows.Forms.Panel();
            this.Flecha = new System.Windows.Forms.PictureBox();
            this.BtnGanancias = new Bunifu.Framework.UI.BunifuFlatButton();
            this.BtnProveedores = new Bunifu.Framework.UI.BunifuFlatButton();
            this.BtnClientes = new Bunifu.Framework.UI.BunifuFlatButton();
            this.BtnTrabajadores = new Bunifu.Framework.UI.BunifuFlatButton();
            this.BtnCompras = new Bunifu.Framework.UI.BunifuFlatButton();
            this.BtnVentas = new Bunifu.Framework.UI.BunifuFlatButton();
            this.BtnProductos = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnDashboard = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.Header = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Salir = new System.Windows.Forms.PictureBox();
            this.Wrapper = new System.Windows.Forms.Panel();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.Sidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Flecha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Header.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Salir)).BeginInit();
            this.Wrapper.SuspendLayout();
            this.SuspendLayout();
            // 
            // Sidebar
            // 
            this.Sidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(32)))));
            this.Sidebar.Controls.Add(this.Flecha);
            this.Sidebar.Controls.Add(this.BtnGanancias);
            this.Sidebar.Controls.Add(this.BtnProveedores);
            this.Sidebar.Controls.Add(this.BtnClientes);
            this.Sidebar.Controls.Add(this.BtnTrabajadores);
            this.Sidebar.Controls.Add(this.BtnCompras);
            this.Sidebar.Controls.Add(this.BtnVentas);
            this.Sidebar.Controls.Add(this.BtnProductos);
            this.Sidebar.Controls.Add(this.label3);
            this.Sidebar.Controls.Add(this.BtnDashboard);
            this.Sidebar.Controls.Add(this.pictureBox2);
            this.Sidebar.Controls.Add(this.label2);
            this.Sidebar.Controls.Add(this.pictureBox1);
            this.Sidebar.Controls.Add(this.shapeContainer1);
            this.Sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.Sidebar.Location = new System.Drawing.Point(0, 0);
            this.Sidebar.Name = "Sidebar";
            this.Sidebar.Size = new System.Drawing.Size(270, 788);
            this.Sidebar.TabIndex = 0;
            this.Sidebar.Paint += new System.Windows.Forms.PaintEventHandler(this.Sidebar_Paint);
            // 
            // Flecha
            // 
            this.Flecha.Image = ((System.Drawing.Image)(resources.GetObject("Flecha.Image")));
            this.Flecha.Location = new System.Drawing.Point(249, 308);
            this.Flecha.Name = "Flecha";
            this.Flecha.Size = new System.Drawing.Size(35, 35);
            this.Flecha.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Flecha.TabIndex = 13;
            this.Flecha.TabStop = false;
            // 
            // BtnGanancias
            // 
            this.BtnGanancias.Activecolor = System.Drawing.Color.Transparent;
            this.BtnGanancias.BackColor = System.Drawing.Color.Transparent;
            this.BtnGanancias.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnGanancias.BorderRadius = 0;
            this.BtnGanancias.ButtonText = "     GANANCIAS";
            this.BtnGanancias.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnGanancias.DisabledColor = System.Drawing.Color.Gray;
            this.BtnGanancias.Iconcolor = System.Drawing.Color.Transparent;
            this.BtnGanancias.Iconimage = ((System.Drawing.Image)(resources.GetObject("BtnGanancias.Iconimage")));
            this.BtnGanancias.Iconimage_right = null;
            this.BtnGanancias.Iconimage_right_Selected = null;
            this.BtnGanancias.Iconimage_Selected = ((System.Drawing.Image)(resources.GetObject("BtnGanancias.Iconimage_Selected")));
            this.BtnGanancias.IconMarginLeft = 0;
            this.BtnGanancias.IconMarginRight = 0;
            this.BtnGanancias.IconRightVisible = true;
            this.BtnGanancias.IconRightZoom = 0D;
            this.BtnGanancias.IconVisible = true;
            this.BtnGanancias.IconZoom = 65D;
            this.BtnGanancias.IsTab = true;
            this.BtnGanancias.Location = new System.Drawing.Point(17, 672);
            this.BtnGanancias.Name = "BtnGanancias";
            this.BtnGanancias.Normalcolor = System.Drawing.Color.Transparent;
            this.BtnGanancias.OnHovercolor = System.Drawing.Color.Transparent;
            this.BtnGanancias.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(195)))), ((int)(((byte)(140)))));
            this.BtnGanancias.selected = false;
            this.BtnGanancias.Size = new System.Drawing.Size(223, 40);
            this.BtnGanancias.TabIndex = 12;
            this.BtnGanancias.Text = "     GANANCIAS";
            this.BtnGanancias.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnGanancias.Textcolor = System.Drawing.Color.White;
            this.BtnGanancias.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnGanancias.Click += new System.EventHandler(this.BtnGanancias_Click);
            // 
            // BtnProveedores
            // 
            this.BtnProveedores.Activecolor = System.Drawing.Color.Transparent;
            this.BtnProveedores.BackColor = System.Drawing.Color.Transparent;
            this.BtnProveedores.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnProveedores.BorderRadius = 0;
            this.BtnProveedores.ButtonText = "     PROVEEDORES";
            this.BtnProveedores.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnProveedores.DisabledColor = System.Drawing.Color.Gray;
            this.BtnProveedores.Iconcolor = System.Drawing.Color.Transparent;
            this.BtnProveedores.Iconimage = ((System.Drawing.Image)(resources.GetObject("BtnProveedores.Iconimage")));
            this.BtnProveedores.Iconimage_right = null;
            this.BtnProveedores.Iconimage_right_Selected = null;
            this.BtnProveedores.Iconimage_Selected = ((System.Drawing.Image)(resources.GetObject("BtnProveedores.Iconimage_Selected")));
            this.BtnProveedores.IconMarginLeft = 0;
            this.BtnProveedores.IconMarginRight = 0;
            this.BtnProveedores.IconRightVisible = true;
            this.BtnProveedores.IconRightZoom = 0D;
            this.BtnProveedores.IconVisible = true;
            this.BtnProveedores.IconZoom = 65D;
            this.BtnProveedores.IsTab = true;
            this.BtnProveedores.Location = new System.Drawing.Point(17, 620);
            this.BtnProveedores.Name = "BtnProveedores";
            this.BtnProveedores.Normalcolor = System.Drawing.Color.Transparent;
            this.BtnProveedores.OnHovercolor = System.Drawing.Color.Transparent;
            this.BtnProveedores.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(195)))), ((int)(((byte)(140)))));
            this.BtnProveedores.selected = false;
            this.BtnProveedores.Size = new System.Drawing.Size(223, 40);
            this.BtnProveedores.TabIndex = 11;
            this.BtnProveedores.Text = "     PROVEEDORES";
            this.BtnProveedores.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnProveedores.Textcolor = System.Drawing.Color.White;
            this.BtnProveedores.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnProveedores.Click += new System.EventHandler(this.BtnProveedores_Click);
            // 
            // BtnClientes
            // 
            this.BtnClientes.Activecolor = System.Drawing.Color.Transparent;
            this.BtnClientes.BackColor = System.Drawing.Color.Transparent;
            this.BtnClientes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnClientes.BorderRadius = 0;
            this.BtnClientes.ButtonText = "     CLIENTE";
            this.BtnClientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnClientes.DisabledColor = System.Drawing.Color.Gray;
            this.BtnClientes.Iconcolor = System.Drawing.Color.Transparent;
            this.BtnClientes.Iconimage = ((System.Drawing.Image)(resources.GetObject("BtnClientes.Iconimage")));
            this.BtnClientes.Iconimage_right = null;
            this.BtnClientes.Iconimage_right_Selected = null;
            this.BtnClientes.Iconimage_Selected = ((System.Drawing.Image)(resources.GetObject("BtnClientes.Iconimage_Selected")));
            this.BtnClientes.IconMarginLeft = 0;
            this.BtnClientes.IconMarginRight = 0;
            this.BtnClientes.IconRightVisible = true;
            this.BtnClientes.IconRightZoom = 0D;
            this.BtnClientes.IconVisible = true;
            this.BtnClientes.IconZoom = 65D;
            this.BtnClientes.IsTab = true;
            this.BtnClientes.Location = new System.Drawing.Point(17, 566);
            this.BtnClientes.Name = "BtnClientes";
            this.BtnClientes.Normalcolor = System.Drawing.Color.Transparent;
            this.BtnClientes.OnHovercolor = System.Drawing.Color.Transparent;
            this.BtnClientes.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(195)))), ((int)(((byte)(140)))));
            this.BtnClientes.selected = false;
            this.BtnClientes.Size = new System.Drawing.Size(223, 40);
            this.BtnClientes.TabIndex = 10;
            this.BtnClientes.Text = "     CLIENTE";
            this.BtnClientes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnClientes.Textcolor = System.Drawing.Color.White;
            this.BtnClientes.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClientes.Click += new System.EventHandler(this.BtnClientes_Click);
            // 
            // BtnTrabajadores
            // 
            this.BtnTrabajadores.Activecolor = System.Drawing.Color.Transparent;
            this.BtnTrabajadores.BackColor = System.Drawing.Color.Transparent;
            this.BtnTrabajadores.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnTrabajadores.BorderRadius = 0;
            this.BtnTrabajadores.ButtonText = "     TRABAJADORES";
            this.BtnTrabajadores.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnTrabajadores.DisabledColor = System.Drawing.Color.Gray;
            this.BtnTrabajadores.Iconcolor = System.Drawing.Color.Transparent;
            this.BtnTrabajadores.Iconimage = ((System.Drawing.Image)(resources.GetObject("BtnTrabajadores.Iconimage")));
            this.BtnTrabajadores.Iconimage_right = null;
            this.BtnTrabajadores.Iconimage_right_Selected = null;
            this.BtnTrabajadores.Iconimage_Selected = ((System.Drawing.Image)(resources.GetObject("BtnTrabajadores.Iconimage_Selected")));
            this.BtnTrabajadores.IconMarginLeft = 0;
            this.BtnTrabajadores.IconMarginRight = 0;
            this.BtnTrabajadores.IconRightVisible = true;
            this.BtnTrabajadores.IconRightZoom = 0D;
            this.BtnTrabajadores.IconVisible = true;
            this.BtnTrabajadores.IconZoom = 65D;
            this.BtnTrabajadores.IsTab = true;
            this.BtnTrabajadores.Location = new System.Drawing.Point(17, 513);
            this.BtnTrabajadores.Name = "BtnTrabajadores";
            this.BtnTrabajadores.Normalcolor = System.Drawing.Color.Transparent;
            this.BtnTrabajadores.OnHovercolor = System.Drawing.Color.Transparent;
            this.BtnTrabajadores.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(195)))), ((int)(((byte)(140)))));
            this.BtnTrabajadores.selected = false;
            this.BtnTrabajadores.Size = new System.Drawing.Size(223, 40);
            this.BtnTrabajadores.TabIndex = 9;
            this.BtnTrabajadores.Text = "     TRABAJADORES";
            this.BtnTrabajadores.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnTrabajadores.Textcolor = System.Drawing.Color.White;
            this.BtnTrabajadores.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTrabajadores.Click += new System.EventHandler(this.BtnTrabajadores_Click);
            // 
            // BtnCompras
            // 
            this.BtnCompras.Activecolor = System.Drawing.Color.Transparent;
            this.BtnCompras.BackColor = System.Drawing.Color.Transparent;
            this.BtnCompras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnCompras.BorderRadius = 0;
            this.BtnCompras.ButtonText = "     COMPRAS";
            this.BtnCompras.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnCompras.DisabledColor = System.Drawing.Color.Gray;
            this.BtnCompras.Iconcolor = System.Drawing.Color.Transparent;
            this.BtnCompras.Iconimage = ((System.Drawing.Image)(resources.GetObject("BtnCompras.Iconimage")));
            this.BtnCompras.Iconimage_right = null;
            this.BtnCompras.Iconimage_right_Selected = null;
            this.BtnCompras.Iconimage_Selected = ((System.Drawing.Image)(resources.GetObject("BtnCompras.Iconimage_Selected")));
            this.BtnCompras.IconMarginLeft = 0;
            this.BtnCompras.IconMarginRight = 0;
            this.BtnCompras.IconRightVisible = true;
            this.BtnCompras.IconRightZoom = 0D;
            this.BtnCompras.IconVisible = true;
            this.BtnCompras.IconZoom = 65D;
            this.BtnCompras.IsTab = true;
            this.BtnCompras.Location = new System.Drawing.Point(17, 458);
            this.BtnCompras.Name = "BtnCompras";
            this.BtnCompras.Normalcolor = System.Drawing.Color.Transparent;
            this.BtnCompras.OnHovercolor = System.Drawing.Color.Transparent;
            this.BtnCompras.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(195)))), ((int)(((byte)(140)))));
            this.BtnCompras.selected = false;
            this.BtnCompras.Size = new System.Drawing.Size(223, 40);
            this.BtnCompras.TabIndex = 8;
            this.BtnCompras.Text = "     COMPRAS";
            this.BtnCompras.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCompras.Textcolor = System.Drawing.Color.White;
            this.BtnCompras.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCompras.Click += new System.EventHandler(this.BtnCompras_Click);
            // 
            // BtnVentas
            // 
            this.BtnVentas.Activecolor = System.Drawing.Color.Transparent;
            this.BtnVentas.BackColor = System.Drawing.Color.Transparent;
            this.BtnVentas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnVentas.BorderRadius = 0;
            this.BtnVentas.ButtonText = "     VENTAS";
            this.BtnVentas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnVentas.DisabledColor = System.Drawing.Color.Gray;
            this.BtnVentas.Iconcolor = System.Drawing.Color.Transparent;
            this.BtnVentas.Iconimage = ((System.Drawing.Image)(resources.GetObject("BtnVentas.Iconimage")));
            this.BtnVentas.Iconimage_right = null;
            this.BtnVentas.Iconimage_right_Selected = null;
            this.BtnVentas.Iconimage_Selected = ((System.Drawing.Image)(resources.GetObject("BtnVentas.Iconimage_Selected")));
            this.BtnVentas.IconMarginLeft = 0;
            this.BtnVentas.IconMarginRight = 0;
            this.BtnVentas.IconRightVisible = true;
            this.BtnVentas.IconRightZoom = 0D;
            this.BtnVentas.IconVisible = true;
            this.BtnVentas.IconZoom = 65D;
            this.BtnVentas.IsTab = true;
            this.BtnVentas.Location = new System.Drawing.Point(17, 406);
            this.BtnVentas.Name = "BtnVentas";
            this.BtnVentas.Normalcolor = System.Drawing.Color.Transparent;
            this.BtnVentas.OnHovercolor = System.Drawing.Color.Transparent;
            this.BtnVentas.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(195)))), ((int)(((byte)(140)))));
            this.BtnVentas.selected = false;
            this.BtnVentas.Size = new System.Drawing.Size(223, 40);
            this.BtnVentas.TabIndex = 7;
            this.BtnVentas.Text = "     VENTAS";
            this.BtnVentas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnVentas.Textcolor = System.Drawing.Color.White;
            this.BtnVentas.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVentas.Click += new System.EventHandler(this.BtnVentas_Click);
            // 
            // BtnProductos
            // 
            this.BtnProductos.Activecolor = System.Drawing.Color.Transparent;
            this.BtnProductos.AllowDrop = true;
            this.BtnProductos.BackColor = System.Drawing.Color.Transparent;
            this.BtnProductos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnProductos.BorderRadius = 0;
            this.BtnProductos.ButtonText = "     PRODUCTOS";
            this.BtnProductos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnProductos.DisabledColor = System.Drawing.Color.Gray;
            this.BtnProductos.Iconcolor = System.Drawing.Color.Transparent;
            this.BtnProductos.Iconimage = ((System.Drawing.Image)(resources.GetObject("BtnProductos.Iconimage")));
            this.BtnProductos.Iconimage_right = null;
            this.BtnProductos.Iconimage_right_Selected = null;
            this.BtnProductos.Iconimage_Selected = ((System.Drawing.Image)(resources.GetObject("BtnProductos.Iconimage_Selected")));
            this.BtnProductos.IconMarginLeft = 0;
            this.BtnProductos.IconMarginRight = 0;
            this.BtnProductos.IconRightVisible = true;
            this.BtnProductos.IconRightZoom = 0D;
            this.BtnProductos.IconVisible = true;
            this.BtnProductos.IconZoom = 65D;
            this.BtnProductos.IsTab = true;
            this.BtnProductos.Location = new System.Drawing.Point(17, 356);
            this.BtnProductos.Name = "BtnProductos";
            this.BtnProductos.Normalcolor = System.Drawing.Color.Transparent;
            this.BtnProductos.OnHovercolor = System.Drawing.Color.Transparent;
            this.BtnProductos.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(195)))), ((int)(((byte)(140)))));
            this.BtnProductos.selected = false;
            this.BtnProductos.Size = new System.Drawing.Size(223, 40);
            this.BtnProductos.TabIndex = 6;
            this.BtnProductos.Text = "     PRODUCTOS";
            this.BtnProductos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnProductos.Textcolor = System.Drawing.Color.White;
            this.BtnProductos.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnProductos.Click += new System.EventHandler(this.BtnProductos_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(168)))), ((int)(((byte)(168)))));
            this.label3.Location = new System.Drawing.Point(110, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "User";
            // 
            // BtnDashboard
            // 
            this.BtnDashboard.Activecolor = System.Drawing.Color.Transparent;
            this.BtnDashboard.BackColor = System.Drawing.Color.Transparent;
            this.BtnDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnDashboard.BorderRadius = 0;
            this.BtnDashboard.ButtonText = "     DASHBOARD";
            this.BtnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnDashboard.DisabledColor = System.Drawing.Color.Gray;
            this.BtnDashboard.Iconcolor = System.Drawing.Color.Transparent;
            this.BtnDashboard.Iconimage = ((System.Drawing.Image)(resources.GetObject("BtnDashboard.Iconimage")));
            this.BtnDashboard.Iconimage_right = null;
            this.BtnDashboard.Iconimage_right_Selected = null;
            this.BtnDashboard.Iconimage_Selected = ((System.Drawing.Image)(resources.GetObject("BtnDashboard.Iconimage_Selected")));
            this.BtnDashboard.IconMarginLeft = 0;
            this.BtnDashboard.IconMarginRight = 0;
            this.BtnDashboard.IconRightVisible = true;
            this.BtnDashboard.IconRightZoom = 0D;
            this.BtnDashboard.IconVisible = true;
            this.BtnDashboard.IconZoom = 65D;
            this.BtnDashboard.IsTab = true;
            this.BtnDashboard.Location = new System.Drawing.Point(17, 308);
            this.BtnDashboard.Name = "BtnDashboard";
            this.BtnDashboard.Normalcolor = System.Drawing.Color.Transparent;
            this.BtnDashboard.OnHovercolor = System.Drawing.Color.Transparent;
            this.BtnDashboard.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(195)))), ((int)(((byte)(140)))));
            this.BtnDashboard.selected = false;
            this.BtnDashboard.Size = new System.Drawing.Size(223, 40);
            this.BtnDashboard.TabIndex = 4;
            this.BtnDashboard.Text = "     DASHBOARD";
            this.BtnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnDashboard.Textcolor = System.Drawing.Color.White;
            this.BtnDashboard.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDashboard.Click += new System.EventHandler(this.BtnDashboard_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(42, 77);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(174, 157);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(168)))), ((int)(((byte)(168)))));
            this.label2.Location = new System.Drawing.Point(120, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "JAMES";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(76, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 35);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape3,
            this.lineShape2});
            this.shapeContainer1.Size = new System.Drawing.Size(270, 788);
            this.shapeContainer1.TabIndex = 2;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape3
            // 
            this.lineShape3.BorderColor = System.Drawing.Color.White;
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 24;
            this.lineShape3.X2 = 234;
            this.lineShape3.Y1 = 61;
            this.lineShape3.Y2 = 61;
            // 
            // lineShape2
            // 
            this.lineShape2.BorderColor = System.Drawing.Color.White;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 17;
            this.lineShape2.X2 = 239;
            this.lineShape2.Y1 = 281;
            this.lineShape2.Y2 = 281;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.White;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 27;
            this.lineShape1.X2 = 163;
            this.lineShape1.Y1 = 761;
            this.lineShape1.Y2 = 761;
            this.lineShape1.Click += new System.EventHandler(this.lineShape1_Click);
            // 
            // Header
            // 
            this.Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(243)))), ((int)(((byte)(239)))));
            this.Header.Controls.Add(this.label1);
            this.Header.Controls.Add(this.Salir);
            this.Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.Header.Location = new System.Drawing.Point(270, 0);
            this.Header.Name = "Header";
            this.Header.Size = new System.Drawing.Size(1016, 45);
            this.Header.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(168)))), ((int)(((byte)(168)))));
            this.label1.Location = new System.Drawing.Point(10, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "DASHBOARD";
            // 
            // Salir
            // 
            this.Salir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Salir.Image = ((System.Drawing.Image)(resources.GetObject("Salir.Image")));
            this.Salir.Location = new System.Drawing.Point(969, 5);
            this.Salir.Name = "Salir";
            this.Salir.Size = new System.Drawing.Size(35, 35);
            this.Salir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Salir.TabIndex = 0;
            this.Salir.TabStop = false;
            this.Salir.Click += new System.EventHandler(this.Salir_Click);
            // 
            // Wrapper
            // 
            this.Wrapper.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(243)))), ((int)(((byte)(239)))));
            this.Wrapper.Controls.Add(this.shapeContainer2);
            this.Wrapper.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Wrapper.Location = new System.Drawing.Point(270, 0);
            this.Wrapper.Name = "Wrapper";
            this.Wrapper.Size = new System.Drawing.Size(1016, 788);
            this.Wrapper.TabIndex = 1;
            this.Wrapper.Paint += new System.Windows.Forms.PaintEventHandler(this.Wrapper_Paint);
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer2.Size = new System.Drawing.Size(1016, 788);
            this.shapeContainer2.TabIndex = 0;
            this.shapeContainer2.TabStop = false;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1286, 788);
            this.Controls.Add(this.Header);
            this.Controls.Add(this.Wrapper);
            this.Controls.Add(this.Sidebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmPrincipal";
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            this.Sidebar.ResumeLayout(false);
            this.Sidebar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Flecha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Header.ResumeLayout(false);
            this.Header.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Salir)).EndInit();
            this.Wrapper.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Sidebar;
        private System.Windows.Forms.Panel Header;
        private System.Windows.Forms.Panel Wrapper;
        private System.Windows.Forms.PictureBox Salir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private System.Windows.Forms.Label label3;
        private Bunifu.Framework.UI.BunifuFlatButton BtnDashboard;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Bunifu.Framework.UI.BunifuFlatButton BtnClientes;
        private Bunifu.Framework.UI.BunifuFlatButton BtnTrabajadores;
        private Bunifu.Framework.UI.BunifuFlatButton BtnCompras;
        private Bunifu.Framework.UI.BunifuFlatButton BtnVentas;
        private Bunifu.Framework.UI.BunifuFlatButton BtnProductos;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Bunifu.Framework.UI.BunifuFlatButton BtnGanancias;
        private Bunifu.Framework.UI.BunifuFlatButton BtnProveedores;
        private System.Windows.Forms.PictureBox Flecha;
    }
}