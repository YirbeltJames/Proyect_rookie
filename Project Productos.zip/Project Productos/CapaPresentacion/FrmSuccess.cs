﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FrmSuccess : Form
    {
        public FrmSuccess(string Mensaje)
        {
            InitializeComponent();
            lblMensaje.Text = Mensaje; 
        }

        private void FrmSuccess_Load(object sender, EventArgs e)
        {
            EsclarecerForm.ShowSync(this); 
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public static void Confirmacionform(string Mensaje) 
        {
            FrmSuccess frm = new FrmSuccess(Mensaje);
            frm.ShowDialog();             
        } 

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }
    }
}
