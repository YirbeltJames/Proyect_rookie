﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaEntidades;
using CapaNegocio; 

namespace CapaPresentacion
{
    public partial class FrmCategoria : Form
    {
        private string idCategoria;
        private bool Editarse = false;

        E_Categoria objEntidad = new E_Categoria();
        N_Categoria objNegocio = new N_Categoria(); 

        public FrmCategoria()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Close(); 
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TablaCategoria_Load(object sender, EventArgs e)
        {
            mostrarBuscarTabla("");
            accionesTablas(); 
        }

        public void mostrarBuscarTabla(string buscar) 
        {
            N_Categoria ObjNegocio = new N_Categoria();
            TablaCategoria.DataSource = ObjNegocio.ListandoCategoria(buscar); 
        }

        public void accionesTablas() 
        {
            TablaCategoria.Columns[0].Visible = false;
            TablaCategoria.Columns[1].Width = 60;
            TablaCategoria.Columns[2].Width = 170;

            TablaCategoria.ClearSelection(); 
        }

        private void txtbuscar_TextChanged(object sender, EventArgs e)
        {
            mostrarBuscarTabla(txtbuscar.Text); 

        }

        private void LimpiarCajas() 
        {
            txtCodigo.Text = "";
            txtNombre.Text = "";
            txtDescripcion.Text = "";
            txtNombre.Focus();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCajas(); 
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (TablaCategoria.SelectedRows.Count > 0)
            {
                Editarse = true; 
                idCategoria = TablaCategoria.CurrentRow.Cells[0].Value.ToString();
                txtCodigo.Text = TablaCategoria.CurrentRow.Cells[1].Value.ToString();
                txtNombre.Text = TablaCategoria.CurrentRow.Cells[2].Value.ToString();
                txtDescripcion.Text = TablaCategoria.CurrentRow.Cells[3].Value.ToString();
            }
            else 
            {
                MessageBox.Show("Selecciona la fila que desea Editar"); 
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (Editarse == false) 
            {
                try
                {
                    objEntidad.Nombrecategoria = txtNombre.Text.ToUpper();
                    objEntidad.Descripcioncategoria = txtDescripcion.Text.ToUpper();

                    objNegocio.InsertarCategoria(objEntidad);

                    FrmSuccess.Confirmacionform("GUARDADO"); 
                    mostrarBuscarTabla("");
                    LimpiarCajas(); 
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("No se pudo guardar correctamente" + Ex);
                }
            }

            if (Editarse == true) 
            {
                try
                {
                    objEntidad.Idcategoria = Convert.ToInt32(idCategoria);
                    objEntidad.Nombrecategoria = txtNombre.Text.ToUpper();
                    objEntidad.Descripcioncategoria = txtDescripcion.Text.ToUpper();

                    objNegocio.EditandoCategoria(objEntidad);

                    FrmSuccess.Confirmacionform("EDITADO");
                    mostrarBuscarTabla("");
                    LimpiarCajas(); 
                    Editarse = false; 
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("No se pudo Editar correctamente" + Ex);
                }
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (TablaCategoria.SelectedRows.Count > 0)
            {
                objEntidad.Idcategoria = Convert.ToInt32(TablaCategoria.CurrentRow.Cells[0].Value.ToString());
                objNegocio.EliminandoCategoria(objEntidad);

                FrmSuccess.Confirmacionform("ELIMINADO");
                mostrarBuscarTabla("");
            }
            else 
            {
                MessageBox.Show("Seleccione la fila que desea eliminar"); 
            }
        }
    }
}
