﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaEntidades;
using CapaNegocio;
using CapaPresentacion; 

namespace CapaPresentacion
{
    public partial class FrmNuevoProducto : Form
    {
        FrmProductos frm = new FrmProductos();
        E_Productos entities = new E_Productos();
        N_Productos Negocio = new N_Productos();

        public bool Update1 = false; 

        public FrmNuevoProducto()
        {
            InitializeComponent();
            ListCategoria(); 
            ListMarca(); 
        }

        private void Cerrar_Click(object sender, EventArgs e)
        {
            Close(); 
        }

         public void LimpiarCajas()
        {
            txtCodigo.Text = "";
            txtNombreProducto.Text = "";
            txtPrecioCompra.Text = "";
            txtStock.Text = "";
            txtPrecioVenta.Text = "";
            CmbCategoria.Text = "";
            CmbMarca.Text = "";
            txtNombreProducto.Focus();
        }

        public void ListCategoria() 
        {
            N_Categoria Negocio = new N_Categoria();
            CmbCategoria.DataSource = Negocio.ListandoCategoria("");
            CmbCategoria.ValueMember = "Idcategoria";
            CmbCategoria.DisplayMember = "NombreCategoria"; 
        }

        public void ListMarca()
        {
            N_Marca Negocio = new N_Marca();
            CmbMarca.DataSource = Negocio.ListandoMarca("");
            CmbMarca.ValueMember = "IdMarca";
            CmbMarca.DisplayMember = "NombreMarca";
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (Update1 == false)
            {
                try
                {
                    entities.Producto = txtNombreProducto.Text.ToUpper();
                    entities.Precio_compra = Convert.ToDecimal(txtPrecioCompra.Text.ToUpper());
                    entities.Precio_venta = Convert.ToDecimal(txtPrecioVenta.Text.ToUpper());
                    entities.Stock = Convert.ToInt32(txtStock.Text.ToUpper());
                    entities.Idcategoria = Convert.ToInt32(CmbCategoria.Text.ToUpper());
                    entities.Idmarca = Convert.ToInt32(CmbMarca.Text.ToUpper());

                    Negocio.CreatingProducts(entities); 
                    FrmSuccess.Confirmacionform("GUARDADO");
                    LimpiarCajas();
                    Close(); 
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("No se pudo guardar correctamente" + Ex);
                }
            }

            if (Update1 == true)
            {
                try
                {
                    entities.Idproductos = Convert.ToInt32(entities.Idproductos);
                    entities.Producto = txtNombreProducto.Text;
                    entities.Precio_compra = Convert.ToDecimal(txtPrecioCompra.Text);
                    entities.Precio_venta = Convert.ToDecimal(txtPrecioVenta.Text);
                    entities.Stock = Convert.ToInt32(txtStock.Text);
                    entities.Idcategoria = Convert.ToInt32(CmbCategoria.SelectedValue);
                    entities.Idmarca = Convert.ToInt32(CmbMarca.SelectedValue);

                    Negocio.UpdatingProducts(entities); 

                    FrmSuccess.Confirmacionform("EDITADO");
                    Close(); 
                    Update1 = false;
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("No se pudo Editar correctamente" + Ex);
                }
            }
        }
    }
}
