﻿using CapaEntidades;
using CapaNegocio;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft; 


namespace CapaPresentacion
{
    public partial class FrmProductos : Form
    {
        ProductBusinnes ObjNegocio = new ProductBusinnes();

        public FrmProductos()
        {
            InitializeComponent();
            MostrarTablaProducto();
            ocultarMoverAncharColumnas();
            ShowTotal(); 
        }

        public void ocultarMoverAncharColumnas()
        {
            TablaProductos.Columns[2].Visible = false;
            TablaProductos.Columns[5].Visible = false;
            TablaProductos.Columns[7].Visible = false;

            TablaProductos.Columns[0].DisplayIndex = 11;
            TablaProductos.Columns[1].DisplayIndex = 11;
        }

        public void MostrarProductos() 
        {
            ProductBusinnes businnes =new ProductBusinnes();
            TablaProductos.DataSource = businnes.ListingProducts(); 
        }

        private void MostrarTablaProducto()
        {
            N_Productos ObjNegocio = new N_Productos();
            TablaProductos.DataSource = ObjNegocio.ListandoProductos();
            ocultarMoverAncharColumnas(); 
        }

        public void SearchProduct(string Search) 
        {
            ProductBusinnes businnes = new ProductBusinnes();
            TablaProductos.DataSource = businnes.SearchingProducts(Search);
            ocultarMoverAncharColumnas();
        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtbuscar_TextChanged(object sender, EventArgs e)
        {
            SearchProduct(txtbuscar.Text);
        }

        private void BtnNuevoProducto_Click(object sender, EventArgs e)
        {
            FrmNuevoProducto frm = new FrmNuevoProducto();
            frm.ShowDialog();
            frm.Update1 = false;
            MostrarProductos();  
        }

        public void ShowTotal() 
        {
            E_Productos entities = new E_Productos();
            N_Productos Bussines = new N_Productos();
            Bussines.SummaringTotals(entities);
            lblCategory.Text = entities.TotalCategoria;
            lblBrands.Text = entities.TotalMarca;
            lblproducts.Text = entities.TotalProductos;
            lblTotalStock.Text = entities.TotalStock; 

        }

        private void TablaProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (TablaProductos.Rows[e.RowIndex].Cells["ELIMINAR"].Selected)
            {
                Form message = new FrmInformation("¿ESTAS SEGURO DE ELIMINAR EL PRODUCTO?");
                DialogResult result = message.ShowDialog();

                if (result == DialogResult.OK)
                {
                    int delete = Convert.ToInt32(TablaProductos.Rows[e.RowIndex].Cells[2].Value.ToString());
                    ObjNegocio.BorrarProduct(delete); 
                    FrmSuccess.Confirmacionform("ELIMINANDO");
                    MostrarProductos();
                }
            }
            else if (TablaProductos.Rows[e.RowIndex].Cells["editar"].Selected)
            {
                FrmNuevoProducto frm = new FrmNuevoProducto();
                frm.Update1 = true;
                frm.txtId.Text = TablaProductos.Rows[e.RowIndex].Cells["Idproductos"].Value.ToString();
                frm.txtCodigo.Text = TablaProductos.Rows[e.RowIndex].Cells["Codigo"].Value.ToString();
                frm.txtNombreProducto.Text = TablaProductos.Rows[e.RowIndex].Cells["Producto"].Value.ToString();
                frm.txtPrecioCompra.Text = TablaProductos.Rows[e.RowIndex].Cells["Precio_compra"].Value.ToString();
                frm.txtPrecioVenta.Text = TablaProductos.Rows[e.RowIndex].Cells["Precio_venta"].Value.ToString();
                frm.txtStock.Text = TablaProductos.Rows[e.RowIndex].Cells["Stock"].Value.ToString();
                frm.CmbCategoria.Text = TablaProductos.Rows[e.RowIndex].Cells["Idcategoria"].Value.ToString();
                frm.CmbMarca.Text = TablaProductos.Rows[e.RowIndex].Cells["Idmarca"].Value.ToString();

                frm.ShowDialog();
                MostrarProductos();
            }
            }

        private void btnNuevaCategoria_Click(object sender, EventArgs e)
        {
            FrmCategoria frm = new FrmCategoria();
            frm.ShowDialog(); 
        }

        private void btnNuevaMarca_Click(object sender, EventArgs e)
        {
            FrmMarca frm = new FrmMarca();
            frm.ShowDialog(); 
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

            worksheet = workbook.Sheets[1];
            worksheet.Name = "Products";

            for (int i = 3; i < TablaProductos.Columns.Count + 1; i++) 
            {
                worksheet.Cells[1, i] = TablaProductos.Columns[i - 1].HeaderText; 
            }

            for (int i = 0; i < TablaProductos.Columns.Count; i++) 
            {
                for (int j = 0; j < TablaProductos.Columns.Count; j++) 
                {
                    worksheet.Cells[i + 2, j + 1] = TablaProductos.Rows[i].Cells[j].Value.ToString(); 
                } 
            }
            app.Visible = true; 
        }
    }
}

