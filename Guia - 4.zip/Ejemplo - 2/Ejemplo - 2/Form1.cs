namespace Ejemplo___2
{
    public partial class Cola : Form
    {

        int total = 0;
        Random Number = new Random();

        public Cola()
        {
            InitializeComponent();
            txtTotal.Text = Convert.ToString(total);
        }

        private void Cola_Load(object sender, EventArgs e)
        {
        }

 
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Cola_Load_1(object sender, EventArgs e)
        {

        }

        private void btnExtraer_Click_1(object sender, EventArgs e)
        {
            if (total == 0)
            {
                MessageBox.Show("Cola vacia, no puede eliminar datos");
            }
            else
            {
                txtn1.Text = txtn2.Text;
                txtn2.Text = txtn3.Text;
                txtn3.Text = txtn4.Text;
                txtn4.Text = txtn5.Text;

                if (total == 1) txtn1.Visible = false;
                if (total == 2) txtn2.Visible = false;
                if (total == 3) txtn3.Visible = false;
                if (total == 4) txtn4.Visible = false;
                if (total == 5) txtn5.Visible = false;
                total--;
                txtTotal.Text = Convert.ToString(total);
                timer2.Enabled = true;
            }

        }

        private void btnIngresar_Click_1(object sender, EventArgs e)
        {
            if (total == 5)
            {
                MessageBox.Show("La cola esta llena");
            }
            else
            {
                total++;
                txtTotal.Text = Convert.ToString(total);

                switch (total)
                {
                    case 1:
                        txtn1.Text = Convert.ToString(Number.Next(1, 99));
                        txtn1.Visible = true;
                        break;

                    case 2:
                        txtn2.Text = Convert.ToString(Number.Next(1, 99));
                        txtn2.Visible = true;
                        break;

                    case 3:
                        txtn3.Text = Convert.ToString(Number.Next(1, 99));
                        txtn3.Visible = true;
                        break;

                    case 4:
                        txtn4.Text = Convert.ToString(Number.Next(1, 99));
                        txtn4.Visible = true;
                        break;

                    case 5:
                        txtn5.Text = Convert.ToString(Number.Next(1, 99));
                        txtn5.Visible = true;
                        break;

                    default:
                        MessageBox.Show("Error en la cola");
                        break;
                }
                //timer1.Enabled = true;
            }
        }
               private void timer1_Tick_1(object sender, EventArgs e)
        {
            btnIngresar.Enabled = false;

            if (total == 1)
            {
                pbox1.Left = pbox1.Left + 5;
                if (pbox1.Left >= 300) timer1.Enabled = false;
            }

            if (total == 2)
            {
                pbox2.Left = pbox2.Left + 5;
                if (pbox2.Left >= 300) timer1.Enabled = false;
            }

            if (total == 3)
            {
                pbox3.Left = pbox3.Left + 5;
                if (pbox3.Left >= 300) timer1.Enabled = false;
            }

            if (total == 4)
            {
                pbox4.Left = pbox4.Left + 5;
                if (pbox4.Left >= 300) timer1.Enabled = false;
            }

            if (total == 5)
            {
                pbox5.Left = pbox5.Left + 5;
                if (pbox5.Left >= 300) timer1.Enabled = false;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            btnExtraer.Enabled = false;
            pbox1.Left = pbox1.Left + 5;

            if (pbox1.Left >= 600)
            {
                pbox1.Left = 300;
                if (total == 4) pbox5.Left = -50;
                if (total == 3) pbox4.Left = -50;
                if (total == 2) pbox3.Left = -50;
                if (total == 1) pbox2.Left = -50;
                timer2.Enabled = false;
            }
            if (timer2.Enabled == false) btnExtraer.Enabled = true;
        }
    }
}
