﻿namespace Ejemplo___2
{
    partial class Cola
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            txtTotal = new TextBox();
            txtn5 = new TextBox();
            txtn1 = new TextBox();
            txtn2 = new TextBox();
            txtn3 = new TextBox();
            txtn4 = new TextBox();
            pbox1 = new PictureBox();
            pbox2 = new PictureBox();
            pbox3 = new PictureBox();
            pbox4 = new PictureBox();
            pbox5 = new PictureBox();
            btnIngresar = new Button();
            btnExtraer = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pbox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbox5).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(11, 12);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 0;
            label1.Text = "label1";
            // 
            // txtTotal
            // 
            txtTotal.Location = new Point(224, 31);
            txtTotal.Multiline = true;
            txtTotal.Name = "txtTotal";
            txtTotal.Size = new Size(44, 53);
            txtTotal.TabIndex = 1;
            // 
            // txtn5
            // 
            txtn5.Location = new Point(300, 215);
            txtn5.Name = "txtn5";
            txtn5.Size = new Size(49, 23);
            txtn5.TabIndex = 2;
            // 
            // txtn1
            // 
            txtn1.Location = new Point(100, 215);
            txtn1.Name = "txtn1";
            txtn1.Size = new Size(49, 23);
            txtn1.TabIndex = 4;
            txtn1.TextChanged += textBox4_TextChanged;
            // 
            // txtn2
            // 
            txtn2.Location = new Point(150, 215);
            txtn2.Name = "txtn2";
            txtn2.Size = new Size(49, 23);
            txtn2.TabIndex = 5;
            // 
            // txtn3
            // 
            txtn3.Location = new Point(200, 215);
            txtn3.Name = "txtn3";
            txtn3.Size = new Size(49, 23);
            txtn3.TabIndex = 6;
            // 
            // txtn4
            // 
            txtn4.Location = new Point(250, 215);
            txtn4.Name = "txtn4";
            txtn4.Size = new Size(49, 23);
            txtn4.TabIndex = 7;
            // 
            // pbox1
            // 
            pbox1.Location = new Point(50, 150);
            pbox1.Name = "pbox1";
            pbox1.Size = new Size(49, 49);
            pbox1.TabIndex = 8;
            pbox1.TabStop = false;
            // 
            // pbox2
            // 
            pbox2.Location = new Point(50, 150);
            pbox2.Name = "pbox2";
            pbox2.Size = new Size(49, 49);
            pbox2.TabIndex = 9;
            pbox2.TabStop = false;
            // 
            // pbox3
            // 
            pbox3.Location = new Point(50, 150);
            pbox3.Name = "pbox3";
            pbox3.Size = new Size(49, 49);
            pbox3.TabIndex = 10;
            pbox3.TabStop = false;
            // 
            // pbox4
            // 
            pbox4.Location = new Point(50, 150);
            pbox4.Name = "pbox4";
            pbox4.Size = new Size(49, 49);
            pbox4.TabIndex = 11;
            pbox4.TabStop = false;
            // 
            // pbox5
            // 
            pbox5.Location = new Point(50, 150);
            pbox5.Name = "pbox5";
            pbox5.Size = new Size(49, 49);
            pbox5.TabIndex = 12;
            pbox5.TabStop = false;
            // 
            // btnIngresar
            // 
            btnIngresar.Location = new Point(416, 26);
            btnIngresar.Name = "btnIngresar";
            btnIngresar.Size = new Size(75, 23);
            btnIngresar.TabIndex = 13;
            btnIngresar.Text = "INGRESAR";
            btnIngresar.UseVisualStyleBackColor = true;
            btnIngresar.Click += btnIngresar_Click_1;
            // 
            // btnExtraer
            // 
            btnExtraer.Location = new Point(534, 26);
            btnExtraer.Name = "btnExtraer";
            btnExtraer.Size = new Size(75, 23);
            btnExtraer.TabIndex = 14;
            btnExtraer.Text = "EXTRAER";
            btnExtraer.UseVisualStyleBackColor = true;
            btnExtraer.Click += btnExtraer_Click_1;
            // 
            // timer1
            // 
            timer1.Interval = 10;
            timer1.Tick += timer1_Tick_1;
            // 
            // timer2
            // 
            timer2.Interval = 10;
            timer2.Tick += timer2_Tick;
            // 
            // Cola
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(656, 317);
            Controls.Add(btnExtraer);
            Controls.Add(btnIngresar);
            Controls.Add(pbox5);
            Controls.Add(pbox4);
            Controls.Add(pbox3);
            Controls.Add(pbox2);
            Controls.Add(pbox1);
            Controls.Add(txtn4);
            Controls.Add(txtn3);
            Controls.Add(txtn2);
            Controls.Add(txtn1);
            Controls.Add(txtn5);
            Controls.Add(txtTotal);
            Controls.Add(label1);
            Name = "Cola";
            Text = "Form1";
            Load += Cola_Load_1;
            ((System.ComponentModel.ISupportInitialize)pbox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtTotal;
        private TextBox txtn5;
        private TextBox txtn1;
        private TextBox txtn2;
        private TextBox txtn3;
        private TextBox txtn4;
        private PictureBox pbox1;
        private PictureBox pbox2;
        private PictureBox pbox3;
        private PictureBox pbox4;
        private PictureBox pbox5;
        private Button btnIngresar;
        private Button btnExtraer;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}