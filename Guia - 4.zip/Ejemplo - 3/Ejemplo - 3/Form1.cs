﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejemplo___3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void Clear() 
        {
            txtCarnet.Clear();
            txtNombre.Clear();
            txtSalario.Clear(); 
        }


        class Empleados 
        {
          public string Carnet { get; set; }
          public string Nombre { get; set; }
          public decimal Salario { get; set; }
          public DateTime Fecha { get; set; }
        }

        Queue<Empleados> Trabajadores = new Queue<Empleados>();

        private void btnRegistro_Click(object sender, EventArgs e)
        {
            Empleados empleado = new Empleados();
            empleado.Carnet = txtCarnet.Text;
            empleado.Nombre = txtNombre.Text;
            empleado.Salario = Convert.ToDecimal(txtSalario.Text);
            empleado.Fecha = txtFecha.Value;

            Trabajadores.Enqueue(empleado);
            dvgCola.DataSource = null;
            dvgCola.DataSource = Trabajadores.ToArray();
            Clear();
            txtCarnet.Focus(); 
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (Trabajadores.Count != 0)
            {
                Empleados empleados = new Empleados();
                empleados = Trabajadores.Dequeue();

                txtCarnet.Text = empleados.Carnet;
                txtNombre.Text = empleados.Nombre;
                txtSalario.Text = empleados.Salario.ToString();
                txtFecha.Value = empleados.Fecha;

                dvgCola.DataSource = Trabajadores.ToList();
                MessageBox.Show("Se elimino el registro en cola", "AVISO");
                Clear();
            }
            else
            {
                MessageBox.Show("No hay Empleados en la cola", "AVISO");
                Clear();
            }
            txtCarnet.Focus(); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
    }
}
