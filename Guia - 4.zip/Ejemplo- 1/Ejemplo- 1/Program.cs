﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo__1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cola objcola = new Cola();
            Console.WriteLine("Colocando elementos:");

            objcola.Encolar(3);
            objcola.Encolar(3);
            objcola.Encolar(3);
            objcola.Encolar(20);
            objcola.Encolar(20);
            objcola.Mostrar();

            Console.WriteLine("Retirando 2 elementos:");
            objcola.Desencolar();
            objcola.Mostrar();
            objcola.Desencolar();
            objcola.Mostrar();

            Console.WriteLine("Se va a retirar un nodo mas, con el valor de {0}", objcola.DesencolarValor());

            objcola.Mostrar();
            Console.ReadLine(); 
        }
    }

    class nodo
    {
        public int info;
        public nodo follow; 
    }

    class Cola 
    {
        public nodo first;
        public nodo last;

        public Cola() 
        {
            first = last = null; 
        }

        public void Encolar(int var) 
        {
            nodo aux = new nodo();
            aux.info = var;

            if (first == null)
            {
                first = last = aux;
                aux.follow = null;
            }
            else 
            {
              last.follow = aux; 
              aux.follow = null;
              last = aux; 
            }
        }

        public void Desencolar()
        {
            if (first == null)
            {
                Console.WriteLine("Cola vacia");
            }
            else 
            {
                first = first.follow; 
            }
        }

        public int DesencolarValor() 
        {
            int valor = 0;
            if (first == null) 
            {
                valor = first.info;
                first = first.follow; 
            }
            return valor; 
        }

        public void Mostrar() 
        {
            if (first == null) Console.WriteLine("Cola vacia");
            else 
            {
                nodo puntero;
                puntero = first;

                do
                {
                    Console.Write("{0}\t", first.info);
                    puntero = puntero.follow; 
                }
                while (puntero != null); 
            }
            Console.WriteLine("\n"); 
        }
    }   
}
